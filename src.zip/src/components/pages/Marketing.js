import React from 'react';

export default function Marketing() {
  return (
    <>
      <h1 className='marketing'>MARKETING</h1>
    </>
  );
}