

export const ConsultingList = [
  {
    name: "Consulting Service 1",
    description: "Description for Consulting Service 1",
  },
  {
    name: "Consulting Service 2",
    description: "Description for Consulting Service 2",
  },
  {
    name: "Consulting Service 3",
    description: "Description for Consulting Service 3",
  },

];
